package vn.com.fsoft.vendingmachines.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.com.fsoft.vendingmachines.dto.UserDTO;
import vn.com.fsoft.vendingmachines.service.UserService;


@RestController
public class UserController {

	@Autowired
	UserService userService;

	@GetMapping(value = "/user")
	public List<UserDTO> getAll() {
		return userService.getAll();
	}

}
