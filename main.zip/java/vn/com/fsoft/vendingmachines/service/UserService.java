package vn.com.fsoft.vendingmachines.service;

import vn.com.fsoft.vendingmachines.dto.UserDTO;
import vn.com.fsoft.vendingmachines.entity.User;

import java.util.List;



public interface UserService {
	
	List<UserDTO> getAll();

}
