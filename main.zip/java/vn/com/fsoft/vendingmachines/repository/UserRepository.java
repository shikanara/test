package vn.com.fsoft.vendingmachines.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import vn.com.fsoft.vendingmachines.entity.User;


@Repository
public interface UserRepository extends JpaRepository<User, String> {

}
