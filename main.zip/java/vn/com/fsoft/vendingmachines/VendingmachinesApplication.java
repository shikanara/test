package vn.com.fsoft.vendingmachines;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendingmachinesApplication {

	public static void main(String[] args) {
		SpringApplication.run(VendingmachinesApplication.class, args);
	}

}
