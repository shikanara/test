package vn.com.fsoft.vendingmachines.entity;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "role_entity")
public class Role {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", columnDefinition = "serial")
	private long id;

	@Column(name = "name", columnDefinition = "VARCHAR(10)")
	private String name;

	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinTable(name = "userrole_entity", joinColumns = @JoinColumn(name = "roleid",
            referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "username", referencedColumnName = "username"))
	private User user ;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Role(String name) {
		this.name = name;
	}

	public Role() {

	}

	public Role(long id, String name) {
		this.id = id;
		this.name = name;
	}
}
