package vn.com.fsoft.vendingmachines.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Entity
@Data
@Table(name = "user_entity")
public class User {

	@Id
	@Column(name = "username", columnDefinition = "VARCHAR(10)")
	private String userName;

	@JsonIgnore
	@Column(name = "password", columnDefinition = "VARCHAR(10)")
	private String password;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private List<Role> userRoles = new ArrayList<Role>();

	public List<Role> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(List<Role> userRoles) {
		this.userRoles = userRoles;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password; 	
	}

	public User() {

	}

	public User(String userName, String password) {
		this.userName = userName;
		this.password = password;
	}

}
