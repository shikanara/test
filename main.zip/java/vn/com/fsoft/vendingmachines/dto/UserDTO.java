package vn.com.fsoft.vendingmachines.dto;

import vn.com.fsoft.vendingmachines.entity.Role;

import java.util.List;

public class UserDTO {
    private String usernamedto;
    private List<Role> rolesdto;

    public UserDTO(String usernamedto, List<Role> rolesdto) {
        this.usernamedto = usernamedto;
        this.rolesdto = rolesdto;
    }

    public UserDTO() {
    }

    public String getUsernamedto() {
        return usernamedto;
    }

    public void setUsernamedto(String usernamedto) {
        this.usernamedto = usernamedto;
    }

    public List<Role> getRolesdto() {
        return rolesdto;
    }

    public void setRolesdto(List<Role> rolesdto) {
        this.rolesdto = rolesdto;
    }
}
