package vn.com.fsoft.vendingmachines.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import vn.com.fsoft.vendingmachines.dto.UserDTO;
import vn.com.fsoft.vendingmachines.entity.User;
import vn.com.fsoft.vendingmachines.mapper.UserMapper;
import vn.com.fsoft.vendingmachines.repository.UserRepository;
import vn.com.fsoft.vendingmachines.service.UserService;


@Service(value = "userService")
public class UserImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserMapper userMapper;

	@Override
	public List<UserDTO> getAll() {
		List<User> users = userRepository.findAll();
		List<UserDTO> userDTOs = new ArrayList<>();

		for (User user: users) {
			userDTOs.add(userMapper.userToUserDTO(user));
		}

		return userDTOs;
	}

}
