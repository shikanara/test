package vn.com.fsoft.vendingmachines.mapper;

import org.mapstruct.*;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import vn.com.fsoft.vendingmachines.dto.UserDTO;
import vn.com.fsoft.vendingmachines.entity.User;

import java.util.List;

@Mapper(componentModel = "spring")

public interface UserMapper {
    @Mappings({
            @Mapping(source = "user.username",target = "usernamedto"),
            @Mapping(source = "user.userRoles",target = "rolesdto")
    })
    UserDTO userToUserDTO(User user);

    @Mappings({
            @Mapping(source = "userDTO.usernamedto",target = "username"),
            @Mapping(source = "userDTO.rolesdto",target = "userRoles")
    })
    User userDTOToUser(UserDTO userDTO);

    List<UserDTO> usersToUserDTOs(List<User> users);

    List<User> UserDTOsTousers(List<UserDTO> userDTOs);

}
